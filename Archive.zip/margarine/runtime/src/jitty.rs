use std::{collections::HashMap, mem::offset_of};

use cranelift::{codegen::{self, ir::FuncRef}, prelude::{settings, types::{F64, I64, I64X2}, AbiParam, Block, Configurable, FloatCC, FunctionBuilder, FunctionBuilderContext, InstBuilder, IntCC, MemFlags, Signature, Type, Value}};
use cranelift_jit::{JITBuilder, JITMemoryProvider, JITModule};
use cranelift_module::{DataDescription, FuncId, Linkage, Module};

use crate::{opcode::runtime::{Decoded, OpCode}, runtime::ret_instr, Function, FunctionKind, Reader, Reg, Stack, Status, VM};

pub struct JIT {
    builder_ctx: FunctionBuilderContext,
    ctx: codegen::Context,
    data_description: DataDescription,
    module: JITModule,

    ret_instr: FuncId,
}


impl JIT {
    pub fn default() -> Self {
        let mut flag_builder = settings::builder();
        flag_builder.set("use_colocated_libcalls", "false").unwrap();
        flag_builder.set("is_pic", "false").unwrap();
        let isa_builder = cranelift_native::builder().unwrap_or_else(|msg| {
            panic!("host machine is not supported: {}", msg);
        });

        let isa = isa_builder
            .finish(settings::Flags::new(flag_builder))
            .unwrap();

        let ptr = isa.pointer_type();
        let conv = isa.default_call_conv();

        let mut builder = JITBuilder::with_isa(isa, cranelift_module::default_libcall_names());
        builder.symbol("ret_instr", ret_instr as _);

        let mut module = JITModule::new(builder);


        let sig = Signature {
            params: vec![AbiParam::new(ptr), AbiParam::new(I64), AbiParam::new(ptr)],
            returns: vec![],
            call_conv: conv,
        };

        let ret_instr = module.declare_function("ret_instr", cranelift_module::Linkage::Import, &sig).unwrap();

        Self {
            builder_ctx: FunctionBuilderContext::new(),
            ctx: module.make_context(),
            data_description: DataDescription::new(),
            module,

            ret_instr,
        }
    }
}


#[derive(Debug)]
pub enum JITResult<'src> {
    Success,
    HostFunction,
    UnsupportedInstr(usize, Decoded<'src>),
    UnsupportedArgType(u32),
}


pub fn attempt_jit<'src>(vm: &mut VM<'src>, idx: usize) -> JITResult<'src> {
    let result = attempt_jit_ex(vm, idx);

    if !matches!(result, JITResult::Success) {
        vm.jit.builder_ctx = FunctionBuilderContext::new();
        vm.jit.module.clear_context(&mut vm.jit.ctx);
    }

    result
}


fn attempt_jit_ex<'src>(vm: &mut VM<'src>, idx: usize) -> JITResult<'src> {
    let func = &vm.funcs[idx];
    println!("attemptiing to jit {}", func.name);
    let FunctionKind::Code { byte_offset, byte_size } = func.kind
    else { return JITResult::HostFunction };

    let src = &vm.callstack.src[byte_offset..byte_offset+byte_size];

    let ptr_ty = vm.jit.module.target_config().pointer_type();

    // fn(*mut VM, *mut Reg)
    vm.jit.ctx.func.signature = Signature {
        params: vec![
            AbiParam::new(ptr_ty),
            AbiParam::new(ptr_ty),
            AbiParam::new(ptr_ty),
        ],
        returns: vec![],
        call_conv: vm.jit.module.target_config().default_call_conv,
    };


    let ret_instr = vm.jit.module.declare_func_in_func(vm.jit.ret_instr, &mut vm.jit.ctx.func);


    let mut builder = FunctionBuilder::new(
        &mut vm.jit.ctx.func,
        &mut vm.jit.builder_ctx
    );


    // infer basic block offsets
    let bbs = {
        let mut reader = Reader::new(src);
        let mut block_start = 0;
        let mut bbs = HashMap::new();

        while let Some(opcode) = OpCode::decode(&mut reader) {
            match opcode.1 {
                  crate::opcode::runtime::Decoded::Ret { .. }
                | crate::opcode::runtime::Decoded::Jump { .. }
                | crate::opcode::runtime::Decoded::SwitchOn { .. }
                | crate::opcode::runtime::Decoded::Err { .. }
                | crate::opcode::runtime::Decoded::Switch { .. } => {
                    let offset = reader.offset_from_start();
                    let bb = builder.create_block();
                    bbs.insert(block_start, bb);
                    block_start = offset;
                },

                _ => (),
            }

        }

        bbs.insert(reader.offset_from_start(), builder.create_block());

        bbs
    };

    builder.switch_to_block(bbs[&0]);
    builder.append_block_params_for_function_params(bbs[&0]);


    let vm_ptr = builder.block_params(bbs[&0])[0];
    let ret_ptr = builder.block_params(bbs[&0])[1];
    let status_ptr = builder.block_params(bbs[&0])[2];

    let curr_offset = offset_of!(VM, stack.curr);
    let bottom_offset = offset_of!(VM, stack.bottom);
    let values_offset = offset_of!(VM, stack.values);

    let values_ptr = builder.ins().iadd_imm(vm_ptr, values_offset as i64);
    let values_ptr = builder.ins().load(ptr_ty, MemFlags::new(), values_ptr, 0);

    let curr_ptr   = builder.ins().iadd_imm(vm_ptr, curr_offset as i64);

    let bottom_ptr = builder.ins().iadd_imm(vm_ptr, bottom_offset as i64);
    let bottom     = builder.ins().load(I64, MemFlags::new(), bottom_ptr, 0);
    
    builder.ins().nop();


    let mut reader = Reader::new(&src);

    while let Some(opcode) = OpCode::decode(&mut reader) {
        let offset = reader.offset_from_start();
        let result = decode_instr(
            offset, opcode.1, &bbs, &mut builder, ptr_ty, func,
            ret_instr, vm_ptr, ret_ptr, values_ptr, curr_ptr, bottom,
        );

        if !result {
            return JITResult::UnsupportedInstr(offset, opcode.1);
        }
    }

    for block in bbs {
        builder.seal_block(block.1);
    }

    dbg!(&builder.func);
    builder.finalize();

    let id = vm.jit
        .module
        .declare_function(&func.name, Linkage::Export, &vm.jit.ctx.func.signature)
        .map_err(|e| e.to_string()).unwrap();


    vm.jit.module
        .define_function(id, &mut vm.jit.ctx)
        .map_err(|e| e.to_string()).unwrap();

    vm.jit.module.clear_context(&mut vm.jit.ctx);

    vm.jit.module.finalize_definitions().unwrap();
    let code = vm.jit.module.get_finalized_function(id);

    let func: unsafe extern "C" fn(&mut VM, &mut Reg, &mut Status) = unsafe { std::mem::transmute(code) };

    vm.funcs[idx].kind = FunctionKind::Host(func);

    //vm.funcs[idx].kind = FunctionKind::Host(func);

    JITResult::Success
}


fn decode_instr(
    offset: usize,
    instr: Decoded,
    bbs: &HashMap<usize, Block>,
    builder: &mut FunctionBuilder,
    ptr_ty: Type,
    func: &Function,

    ret_instr: FuncRef,

    vm_ptr      : Value,
    ret_ptr     : Value,
    values_ptr  : Value,
    curr_ptr    : Value,
    bottom      : Value,
) -> bool {
    macro_rules! push_const {
        ($reg: expr) => {
            let stack_offset = builder.ins().load(I64, MemFlags::new(), curr_ptr, 0);
            let offset = builder.ins().imul_imm(stack_offset, size_of::<Reg>() as i64);
            let offset = builder.ins().iadd(values_ptr, offset);
            
            let tag = builder.ins().iconst(I64, $reg.kind as i64);
            let data = builder.ins().iconst(I64, unsafe { $reg.data.as_int });

            builder.ins().store(MemFlags::new(), tag , offset, offset_of!(Reg, kind) as i32);
            builder.ins().store(MemFlags::new(), data, offset, offset_of!(Reg, data) as i32);

            let curr = builder.ins().iadd_imm(stack_offset, 1);
            builder.ins().store(MemFlags::new(), curr, curr_ptr, 0);
        };
    }


    macro_rules! pop {
        ($ty: expr) => {{
            let curr = builder.ins().load(I64, MemFlags::new(), curr_ptr, 0);
            let curr = builder.ins().iadd_imm(curr, -1);

            let offset = builder.ins().imul_imm(curr, size_of::<Reg>() as i64);
            let offset = builder.ins().iadd(values_ptr, offset);

            let data = builder.ins().load($ty, MemFlags::new(), offset, offset_of!(Reg, data) as i32);
            let kind = builder.ins().load(I64, MemFlags::new(), offset, offset_of!(Reg, kind) as i32);

            builder.ins().store(MemFlags::new(), curr, curr_ptr, 0);

            (data, kind)
        }};
    }


    macro_rules! push {
        ($data: expr, $kind: expr) => {{
            let curr = builder.ins().load(I64, MemFlags::new(), curr_ptr, 0);

            let offset = builder.ins().imul_imm(curr, size_of::<Reg>() as i64);
            let offset = builder.ins().iadd(values_ptr, offset);

            builder.ins().store(MemFlags::new(), $data, offset, offset_of!(Reg, data) as i32);
            builder.ins().store(MemFlags::new(), $kind, offset, offset_of!(Reg, kind) as i32);

            let curr = builder.ins().iadd_imm(curr, 1);
            builder.ins().store(MemFlags::new(), curr, curr_ptr, 0);
        }};
    }


    macro_rules! reg_at {
        ($offset: expr) => {{
            let offset = builder.ins().iadd_imm(bottom, $offset as i64);
            let offset = builder.ins().imul_imm(offset, size_of::<Reg>() as i64);

            let ptr = builder.ins().iadd(values_ptr, offset);
            ptr
        }};
    }

    match instr {
        Decoded::Jump { offset: jmp_offset } => {
            let bb = bbs[&((offset as i32 + jmp_offset) as usize)];

            builder.ins().jump(bb, &[]);

            builder.switch_to_block(bbs[&offset]);
            return true;
        },


        Decoded::SwitchOn { true_offset, false_offset } => {
            let true_bb = bbs[&((offset as i32 + true_offset) as usize)];
            let false_bb = bbs[&((offset as i32 + false_offset) as usize)];

            let (cond, _) = pop!(I64);

            builder.ins().brif(cond, true_bb, &[], false_bb, &[]);

            builder.switch_to_block(bbs[&offset]);
            return true;
        },


        Decoded::PushLocalSpace { amount } => {
            let curr = builder.ins().load(I64, MemFlags::new(), curr_ptr, 0);
            let curr = builder.ins().iadd_imm(curr, amount as i64);
            builder.ins().store(MemFlags::new(), curr, curr_ptr, 0);
        }


        Decoded::Ret { local_count } => {
            let imm = builder.ins().iconst(I64, local_count as i64);

            builder.ins().call(ret_instr, &[vm_ptr, imm, ret_ptr]);
            builder.ins().return_(&[]);

            builder.switch_to_block(bbs[&offset]);
            return true;
        }


        Decoded::Unit {  } => {
            push_const!(Reg::new_unit());
        },


        Decoded::ConstInt { val } => {
            push_const!(Reg::new_int(val));
        },


        Decoded::ConstFloat { val } => {
            let data = builder.ins().f64const(val);
            let kind = builder.ins().iconst(I64, Reg::TAG_FLOAT as i64);
            push!(data, kind);
        },


        Decoded::ConstBool { val } => {
            push_const!(Reg::new_bool(val != 0));
        },


        Decoded::AddInt { } => {
            let (rhs, _) = pop!(I64);
            let (lhs, _) = pop!(I64);

            let result = builder.ins().iadd(lhs, rhs);
            let kind = builder.ins().iconst(I64, Reg::TAG_INT as i64);

            push!(result, kind);
        }


        Decoded::SubInt { } => {
            let (rhs, _) = pop!(I64);
            let (lhs, _) = pop!(I64);

            let result = builder.ins().isub(lhs, rhs);
            let kind = builder.ins().iconst(I64, Reg::TAG_INT as i64);

            push!(result, kind);
        }


        Decoded::MulInt { } => {
            let (rhs, _) = pop!(I64);
            let (lhs, _) = pop!(I64);

            let result = builder.ins().imul(lhs, rhs);
            let kind = builder.ins().iconst(I64, Reg::TAG_INT as i64);

            push!(result, kind);
        }


        Decoded::DivInt { } => {
            let (rhs, _) = pop!(I64);
            let (lhs, _) = pop!(I64);

            let result = builder.ins().udiv(lhs, rhs);
            let kind = builder.ins().iconst(I64, Reg::TAG_INT as i64);

            push!(result, kind);
        }


        Decoded::RemInt { } => {
            let (rhs, _) = pop!(I64);
            let (lhs, _) = pop!(I64);

            let result = builder.ins().urem(lhs, rhs);
            let kind = builder.ins().iconst(I64, Reg::TAG_INT as i64);

            push!(result, kind);
        }


        Decoded::AddFloat { } => {
            let (rhs, _) = pop!(F64);
            let (lhs, _) = pop!(F64);

            let result = builder.ins().fadd(lhs, rhs);
            let kind = builder.ins().iconst(I64, Reg::TAG_FLOAT as i64);

            push!(result, kind);
        }


        Decoded::SubFloat { } => {
            let (rhs, _) = pop!(F64);
            let (lhs, _) = pop!(F64);

            let result = builder.ins().fsub(lhs, rhs);
            let kind = builder.ins().iconst(I64, Reg::TAG_FLOAT as i64);

            push!(result, kind);
        }


        Decoded::MulFloat { } => {
            let (rhs, _) = pop!(F64);
            let (lhs, _) = pop!(F64);

            let result = builder.ins().fmul(lhs, rhs);
            let kind = builder.ins().iconst(I64, Reg::TAG_FLOAT as i64);

            push!(result, kind);
        }


        Decoded::DivFloat { } => {
            let (rhs, _) = pop!(F64);
            let (lhs, _) = pop!(F64);

            let result = builder.ins().fdiv(lhs, rhs);
            let kind = builder.ins().iconst(I64, Reg::TAG_FLOAT as i64);

            push!(result, kind);
        }


        Decoded::RemFloat { } => {
            let (rhs, _) = pop!(F64);
            let (lhs, _) = pop!(F64);

            let div = builder.ins().fdiv(lhs, rhs);
            let div_floor = builder.ins().floor(div);
            let y_mul_floor = builder.ins().fmul(rhs, div_floor);
            let rem = builder.ins().fsub(lhs, y_mul_floor);

            let kind = builder.ins().iconst(I64, Reg::TAG_FLOAT as i64);

            push!(rem, kind);
        }


        Decoded::EqInt { } => {
            let (rhs, _) = pop!(I64);
            let (lhs, _) = pop!(I64);

            let result = builder.ins().icmp(IntCC::Equal, lhs, rhs);
            let kind = builder.ins().iconst(I64, Reg::TAG_BOOL as i64);

            push!(result, kind);
        }


        Decoded::NeInt { } => {
            let (rhs, _) = pop!(I64);
            let (lhs, _) = pop!(I64);

            let result = builder.ins().icmp(IntCC::NotEqual, lhs, rhs);
            let kind = builder.ins().iconst(I64, Reg::TAG_BOOL as i64);

            push!(result, kind);
        }


        Decoded::GtInt { } => {
            let (rhs, _) = pop!(I64);
            let (lhs, _) = pop!(I64);

            let result = builder.ins().icmp(IntCC::SignedGreaterThan, lhs, rhs);
            let kind = builder.ins().iconst(I64, Reg::TAG_BOOL as i64);

            push!(result, kind);
        }


        Decoded::GeInt { } => {
            let (rhs, _) = pop!(I64);
            let (lhs, _) = pop!(I64);

            let result = builder.ins().icmp(IntCC::SignedGreaterThanOrEqual, lhs, rhs);
            let kind = builder.ins().iconst(I64, Reg::TAG_BOOL as i64);

            push!(result, kind);
        }


        Decoded::LtInt { } => {
            let (rhs, _) = pop!(I64);
            let (lhs, _) = pop!(I64);

            let result = builder.ins().icmp(IntCC::SignedLessThan, lhs, rhs);
            let kind = builder.ins().iconst(I64, Reg::TAG_BOOL as i64);

            push!(result, kind);
        }


        Decoded::LeInt { } => {
            let (rhs, _) = pop!(I64);
            let (lhs, _) = pop!(I64);

            let result = builder.ins().icmp(IntCC::SignedLessThanOrEqual, lhs, rhs);
            let kind = builder.ins().iconst(I64, Reg::TAG_BOOL as i64);

            push!(result, kind);
        }


        Decoded::EqFloat { } => {
            let (rhs, _) = pop!(F64);
            let (lhs, _) = pop!(F64);

            let result = builder.ins().fcmp(FloatCC::Equal, lhs, rhs);
            let kind = builder.ins().iconst(I64, Reg::TAG_BOOL as i64);

            push!(result, kind);
        }


        Decoded::NeFloat { } => {
            let (rhs, _) = pop!(F64);
            let (lhs, _) = pop!(F64);

            let result = builder.ins().fcmp(FloatCC::NotEqual, lhs, rhs);
            let kind = builder.ins().iconst(I64, Reg::TAG_BOOL as i64);

            push!(result, kind);
        }


        Decoded::GtFloat { } => {
            let (rhs, _) = pop!(F64);
            let (lhs, _) = pop!(F64);

            let result = builder.ins().fcmp(FloatCC::GreaterThan, lhs, rhs);
            let kind = builder.ins().iconst(I64, Reg::TAG_BOOL as i64);

            push!(result, kind);
        }


        Decoded::GeFloat { } => {
            let (rhs, _) = pop!(F64);
            let (lhs, _) = pop!(F64);

            let result = builder.ins().fcmp(FloatCC::GreaterThanOrEqual, lhs, rhs);
            let kind = builder.ins().iconst(I64, Reg::TAG_BOOL as i64);

            push!(result, kind);
        }


        Decoded::LtFloat { } => {
            let (rhs, _) = pop!(F64);
            let (lhs, _) = pop!(F64);

            let result = builder.ins().fcmp(FloatCC::LessThan, lhs, rhs);
            let kind = builder.ins().iconst(I64, Reg::TAG_BOOL as i64);

            push!(result, kind);
        }


        Decoded::LeFloat { } => {
            let (rhs, _) = pop!(F64);
            let (lhs, _) = pop!(F64);

            let result = builder.ins().fcmp(FloatCC::LessThanOrEqual, lhs, rhs);
            let kind = builder.ins().iconst(I64, Reg::TAG_BOOL as i64);

            push!(result, kind);
        }


        Decoded::BitwiseOr { } => {
            let (rhs, _) = pop!(I64);
            let (lhs, _) = pop!(I64);

            let result = builder.ins().bor(lhs, rhs);
            let kind = builder.ins().iconst(I64, Reg::TAG_INT as i64);

            push!(result, kind);
        }


        Decoded::BitwiseAnd { } => {
            let (rhs, _) = pop!(I64);
            let (lhs, _) = pop!(I64);

            let result = builder.ins().band(lhs, rhs);
            let kind = builder.ins().iconst(I64, Reg::TAG_INT as i64);

            push!(result, kind);
        }


        Decoded::BitwiseXor { } => {
            let (rhs, _) = pop!(I64);
            let (lhs, _) = pop!(I64);

            let result = builder.ins().bxor(lhs, rhs);
            let kind = builder.ins().iconst(I64, Reg::TAG_INT as i64);

            push!(result, kind);
        }


        Decoded::BitshiftLeft { } => {
            let (rhs, _) = pop!(I64);
            let (lhs, _) = pop!(I64);

            let result = builder.ins().ishl(lhs, rhs);
            let kind = builder.ins().iconst(I64, Reg::TAG_INT as i64);

            push!(result, kind);
        }


        Decoded::BitshiftRight { } => {
            let (rhs, _) = pop!(I64);
            let (lhs, _) = pop!(I64);

            let result = builder.ins().sshr(lhs, rhs);
            let kind = builder.ins().iconst(I64, Reg::TAG_INT as i64);

            push!(result, kind);
        }


        Decoded::NegInt { } => {
            let (rhs, _) = pop!(I64);

            let result = builder.ins().imul_imm(rhs, -1);
            let kind = builder.ins().iconst(I64, Reg::TAG_INT as i64);

            push!(result, kind);
        }


        Decoded::NotBool { } => {
            let (rhs, _) = pop!(I64);

            let result = builder.ins().bnot(rhs);
            let kind = builder.ins().iconst(I64, Reg::TAG_FLOAT as i64);

            push!(result, kind);
        }


        Decoded::Load { index } => {
            let offset = builder.ins().iadd_imm(bottom, index as i64);
            let offset = builder.ins().imul_imm(offset, size_of::<Reg>() as i64);

            let ptr = builder.ins().iadd(values_ptr, offset);

            let reg_kind = builder.ins().load(I64, MemFlags::new(), ptr, offset_of!(Reg, kind) as i32);
            let reg_data = builder.ins().load(I64, MemFlags::new(), ptr, offset_of!(Reg, data) as i32);

            push!(reg_data, reg_kind);
        }


        Decoded::Store { index } => {
            let (reg, kind) = pop!(I64);
            let ptr = reg_at!(index);

            builder.ins().store(MemFlags::new(), reg, ptr, offset_of!(Reg, data) as i32);
            builder.ins().store(MemFlags::new(), kind, ptr, offset_of!(Reg, kind) as i32);
        }


        Decoded::Pop { } => {
            pop!(I64);
        }

        _ => return false,
    };

    return true;
}


